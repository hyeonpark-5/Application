from flask import Flask, render_template, request
import os
import cv2
import numpy as np
from flask import Flask, render_template,url_for
import matplotlib.pyplot as plt
my_image = "image.jpg"
path = 'C:/Users/sorkg/Documents/python/static/img'
goldhill = cv2.imread("image.jpg",cv2.IMREAD_GRAYSCALE)
app = Flask(__name__)

@app.route('/', methods= ['POST','GET'])
def home():
    if request.method == 'POST':
        V = int(request.form['user'])
        print(V)

    return render_template('value.html')


if __name__ == '__main__':
    app.run(debug = True)